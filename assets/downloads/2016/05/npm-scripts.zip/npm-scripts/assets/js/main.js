const HELLO_STRING = 'Hello World';

console.log(HELLO_STRING);
